CP2101 Evaluation Kit Release 1.1


Run CP2101_Drivers.exe to extract all of the device drivers (Windows and Macintosh).  
To install the drivers, run Setup.exe located in the Win directory under the target
directory you specified when running the CP2101_Drivers.exe program (/Cygnal/Cp2101
by default.)

Note: This version does not include the MacIntosh OS-9 driver. It is available by request from the factory.