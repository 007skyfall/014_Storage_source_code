#ifndef GPRS

#define GPRS

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <termios.h>
#include <errno.h>
#include <iconv.h>
#include <string.h>

#define THIEF 1
#define FIRE  2
#define N  256

#endif

