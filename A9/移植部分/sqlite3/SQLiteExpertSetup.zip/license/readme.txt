After installing the product, copy the license2.key file in the 
installation directory.
Default:"C:\Program Files\SQLite Expert\Professional 3"
